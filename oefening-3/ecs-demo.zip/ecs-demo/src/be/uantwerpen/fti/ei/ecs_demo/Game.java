package be.uantwerpen.fti.ei.ecs_demo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Game
{
	public static void main(String[] args)
	{
		// This will store all of our heroes
		HeroEntity[] allHeroes = new HeroEntity[10];

		// We initialize each hero with a random position and velocity
		for (int i = 0; i < allHeroes.length; ++i)
		{
			allHeroes[i] = new HeroEntity();

			float[] randomPosition = {(float) Math.random(), (float) Math.random()};
			float[] randomVelocity = {(float) Math.random(), (float) Math.random()};

			allHeroes[i].getMovementComponent().setPosition(randomPosition);
			allHeroes[i].getMovementComponent().setVelocity(randomVelocity);
		}

		// This updater will move our heroes a little each time
		MovementSystem updater = new MovementSystem();

		// Run through 100 "frames" of our game
		for (int frame = 0; frame < 100; ++frame)
		{
			// Gather movement components from all entities that have them
			// For this, we convert the heroes array to a stream
			// Map each hero to its movement component
			// And store those in a list
			List<MovementComponent> componentList = Arrays.stream(allHeroes)
					.map(HeroEntity::getMovementComponent)
					.collect(Collectors.toList());

			// We don't even need to store the result, since all objects in Java are pointers anyway,
			// and we didn't make any deep copies
			updater.update(componentList);
		}
	}
}