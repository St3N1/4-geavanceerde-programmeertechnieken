package be.uantwerpen.fti.ei.ecs_demo;

/*
 * The MovementComponent contains all the necessary data to move an entity around.
 * It tracks the current position and velocity, and has methods for updating those.
 */
public class MovementComponent
{
	// Velocity in X and Y direction
	private float vx;
	private float vy;

	// Position in X and Y direction
	private float x;
	private float y;

	public MovementComponent()
	{
		this.vx = 0.0f;
		this.vy = 0.0f;
		this.x = 0.0f;
		this.y = 0.0f;
	}

	public float[] getVelocity()
	{
		return new float[] {this.vx, this.vy};
	}

	public void setVelocity(float[] newVelocity)
	{
		assert 2 == newVelocity.length;

		this.vx = newVelocity[0];
		this.vy = newVelocity[1];
	}

	public float[] getPosition()
	{
		return new float[] {this.x, this.y};
	}

	public void setPosition(float[] newPosition)
	{
		assert 2 == newPosition.length;

		this.x = newPosition[0];
		this.y = newPosition[1];
	}
}
