package be.uantwerpen.fti.ei.ecs_demo;

import java.util.List;

/*
 * The MovementSystem is the system we use to update all our MovementComponents.
 * It contains all the necessary logic, but none of the data.
 * The necessary data is stored in the components themselves.
 */
public class MovementSystem
{
	List<MovementComponent> update(List<MovementComponent> components)
	{
		for (MovementComponent component: components)
		{
			// Get the current position as a starting point for calculating the new position
			float[] newPosition = component.getPosition();

			// Add the velocity to the current position to calculate the new position
			newPosition[0] += component.getVelocity()[0];
			newPosition[1] += component.getVelocity()[1];

			// Store the new position in the component
			component.setPosition(newPosition);
		}

		return components;
	}
}
