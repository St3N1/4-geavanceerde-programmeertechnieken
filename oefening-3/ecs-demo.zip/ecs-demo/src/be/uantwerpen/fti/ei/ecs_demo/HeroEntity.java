package be.uantwerpen.fti.ei.ecs_demo;

/*
 * HeroEntity is our entity.
 * To keep things simple, it stores its components directly, and only contains 1 component: MovementComponent.
 */
public class HeroEntity
{
	private MovementComponent component;

	public HeroEntity()
	{
		this.component = new MovementComponent();
	}

	public MovementComponent getMovementComponent()
	{
		return this.component;
	}

	public void setMovementComponent(MovementComponent component)
	{
		this.component = component;
	}
}
